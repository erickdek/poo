package poo_p2_prueba1_perimetro;
import java.util.*;
/**
 *
 * @author erick
 */
public class POO_P2_PRUEBA1_PERIMETRO {
    public static void main(String[] args) {
        Menu mn = new Menu();
        Scanner sc = new Scanner(System.in);
        //Menu Principal
        mn.MenuPrincipal(sc);
    }
}
