package poo_p1_evaluacion_1;
import java.util.Scanner;

/**
 *
 * @author erick
 * Evaluación 1
 * Enunciado
 * Realizar un programa para la gestión de notas que al iniciarse muestre el siguiente menú:
 * I- Agregar nota
 * 2.- Ver nota media
 * 3.- Ver aprobados
 * 4.- Salir
 * A elegir la opción se solicitará la introducción de una nota y se guardará, volviendo a mostrar de nuevo el menú.
 * Con las opciones 2 y 3 se mostrará, respectivamente, la nota media registrada hasta el momento y el número de 
 * aprobados. A elegir 4 se abandonará el programa
 */
public class POO_P1_EVALUACION_1 {
    public static void main(String[] args) {
        int option = 0, nota = 0, err = 0;
        Scanner req = new Scanner(System.in);
        Notas registro = new Notas();
        do {
            option = 0;
            System.out.println(
                "Bienvenido al sistema de notas." + "\n"
                + "Selecciona una opcion" + "\n"
                + "1. Ingresar notas" + "\n"
                + "2. Ver nota media" + "\n"
                + "3. Ver aprobados" + "\n"
                + "4. Salir" + "\n"
            );
            option = req.nextInt();
            switch(option) {
                case 1:
                    System.out.println("Has seleccionado la opcion 1" + "\n" + "Ingresa las notas de 0 a 10 de puntaje");
                    for (int i = 1; i < 7; i++){
                        System.out.print("\n" + "Nota" + i + " /6: ");
                        nota = req.nextInt();
                        
                        
                        if (nota >= 0 || nota <= 10){
                            registro.setNota(i, nota);
                            nota = 0;
                        } else {err = 1;}
                    }
                    System.out.println("Las notas fueron cargadas");
                    break;
                case 2:
                    System.out.println("Opcion 2");
                    System.out.println("La nota media es: " + registro.media());
                    break;
                case 3:
                    System.out.println("Opcion 3");
                    registro.aprobados();
                    break;
                case 4:
                    System.out.println("Gracias por usar");
                    break;
            }
        } while (option != 4);
    }
}
