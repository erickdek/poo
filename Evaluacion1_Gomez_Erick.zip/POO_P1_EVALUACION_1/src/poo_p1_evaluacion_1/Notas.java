package poo_p1_evaluacion_1;

/**
 *
 * @author erick
 */
public class Notas {
    private int nota1 = 0;
    private int nota2 = 0;
    private int nota3 = 0;
    private int nota4 = 0;
    private int nota5 = 0;
    private int nota6 = 0;
    
    public void showNota(int num, int nota, boolean aprobado ){
        if (aprobado){
            System.out.println("La nota " + num + " con " + nota + " fue aprobada");
        }
    }
    
    public float media() {
        float notaT = this.nota1 + this.nota2 + this.nota3 + this.nota4 + this.nota5 + this.nota6;
        return (notaT/6);
    }
    
    public void setNota (int num, int nota){
        switch (num){
            case 1: this.nota1 = nota; break;
            case 2: this.nota1 = nota; break;
            case 3: this.nota1 = nota; break;
            case 4: this.nota1 = nota; break;
            case 5: this.nota1 = nota; break;
            case 6: this.nota1 = nota; break;
            default: break;
        }
    }
    
    public void aprobados() {
        if (nota1 > 7){
            System.out.println("La nota " + 1 + " con " + nota1 + " fue aprobada");
        }
        if (nota2 > 7){
            System.out.println("La nota " + 2 + " con " + nota2 + " fue aprobada");
        }
        if (nota3 > 7){
            System.out.println("La nota " + 3 + " con " + nota3 + " fue aprobada");
        }
        if (nota4 > 7){
            System.out.println("La nota " + 4 + " con " + nota4 + " fue aprobada");
        }
        if (nota5 > 7){
            System.out.println("La nota " + 5 + " con " + nota5 + " fue aprobada");
        }
        if (nota6 > 7){
            System.out.println("La nota " + 6 + " con " + nota6 + " fue aprobada");
        }
    }
}
