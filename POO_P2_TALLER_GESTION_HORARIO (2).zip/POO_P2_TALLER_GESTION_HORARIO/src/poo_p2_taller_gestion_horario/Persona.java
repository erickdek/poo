package poo_p2_taller_gestion_horario;

/**
 *
 * @author erick
 */
class Persona {
    private String nombre;

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}