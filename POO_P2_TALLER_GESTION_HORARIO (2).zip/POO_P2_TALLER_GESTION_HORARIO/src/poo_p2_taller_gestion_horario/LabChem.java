package poo_p2_taller_gestion_horario;

/**
 *
 * @author erick
 */
class LabChem extends Laboratorio {
    public LabChem(String nombre, String lugar, int capacidadEstudiantes, Persona encargado) {
        super(nombre, lugar, capacidadEstudiantes, encargado);
    }
}
