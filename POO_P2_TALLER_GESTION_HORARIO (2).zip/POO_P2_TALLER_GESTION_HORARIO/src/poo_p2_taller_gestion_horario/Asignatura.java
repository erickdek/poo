package poo_p2_taller_gestion_horario;

/**
 *
 * @author erick
 */
class Asignatura {
    private String nombre;

    public Asignatura(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}