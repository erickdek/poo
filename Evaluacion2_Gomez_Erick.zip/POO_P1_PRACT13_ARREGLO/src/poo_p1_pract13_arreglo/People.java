package poo_p1_pract13_arreglo;

/**
 *
 * @author erick
 */
public class People {
    String name;
    String lastname;
    int age;
    String country;
    
    public People(String name, String lastname, String country, int age){
        this.name = name;
        this.lastname = lastname;
        this.age = age;
        this.country = country;
    }
}
