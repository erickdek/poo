package poo_p1_pract13_arreglo;
import java.util.ArrayList;
/**
 *
 * @author erick
 */
public class Number {
    double num;
    
    public Number( double num){
        this.num = num;
    }
}
