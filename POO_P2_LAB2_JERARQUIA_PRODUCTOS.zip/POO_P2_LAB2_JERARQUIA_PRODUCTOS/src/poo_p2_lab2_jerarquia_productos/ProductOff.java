package poo_p2_lab2_jerarquia_productos;

/**
 *
 * @author erick
 */
public class ProductOff {
    public long offDays = 0;

    public long getDays() {
        return offDays;
    }

    public void setDays(long days) {
        this.offDays = days;
    }
    
}
