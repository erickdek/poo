package poo_p2_lab2_jerarquia_productos;

import java.util.*;
/**
 *
 * @author erick
 */
public class Order {
    int ProductID;
    int CountProduct;
}
